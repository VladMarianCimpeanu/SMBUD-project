"""Current version of package random_italian_things"""
__version__ = "1.0.1"