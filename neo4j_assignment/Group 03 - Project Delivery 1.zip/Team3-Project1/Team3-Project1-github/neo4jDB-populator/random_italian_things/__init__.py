from .random_italian_person import RandomItalianPerson
from .random_italian_house import RandomItalianHouse

__all__ = [
    "RandomItalianPerson", "RandomItalianHouse"

]